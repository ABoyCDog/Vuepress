# dataCom
Building a platform component library using VuePress

(1)npm install or yarn

(2)npm run dos:dev

URL：https://juejin.im/post/5aefc37a6fb9a07ab83df131
